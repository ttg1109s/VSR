// htdocs/engine/modules/Chat.js

import { hideInput } from './chat/Presentation.js';
import { ChatBlockHandlers } from './chat/BlockHandler.js';
import { COMMUNICATION_SENDER_ID, UNKNOWN_SENDER_ID } from './chat/systemSenders.js';

export const ChatSystem = {
    _chatTransitionToken: 0,

    invalidateChatTransition() {
        this._chatTransitionToken = (Number(this._chatTransitionToken) || 0) + 1;
        this.taskManager?.kill?.('chat_transition');
        return this._chatTransitionToken;
    },

    // --- Helper: Quản lý lớp phủ Z-Index ---
    toggleChatOverlay(active) {
        if (this.api.presentation.navigation.setBlocking) {
            this.api.presentation.navigation.setBlocking(active);
        }
        if (this.api.presentation.chat.toggleOverlay) {
            this.api.presentation.chat.toggleOverlay(active);
        }
    },

    getChatOwner(chatId) {
        const chat = this.src.chat?.[chatId];
        const sender = chat?.meta?.sender ?? this.api.engine.state.get('chat.sender', { id: chatId });
        const identityId = this._getCurrentIdentityKey?.() || this.api.engine.state.get('entryCharacter') || 'player';
        if (sender === COMMUNICATION_SENDER_ID) return COMMUNICATION_SENDER_ID;
        const characters = this.src.characters || {};
        const isCharacter = id => id === 'player' || Object.hasOwn(characters, id);
        if (sender && sender !== identityId && isCharacter(sender)) return sender;
        if (sender === identityId) {
            const recipients = Array.isArray(chat?.meta?.to) ? chat.meta.to : [];
            if (recipients.includes(COMMUNICATION_SENDER_ID)) return COMMUNICATION_SENDER_ID;
            const recipient = recipients.find(id => id !== identityId && isCharacter(id));
            if (recipient) return recipient;
        }
        return UNKNOWN_SENDER_ID;
    },

    getThreads(charId) {
        // The HTTP Engine can be started before a scenario is loaded. Snapshot projections
        // must remain safe in that empty-source state instead of dereferencing this.src.
        if (!this.src || typeof this.src !== 'object') return [];
        let chatIds = [];
        const state = this.api.engine.state;
        const chats = state.getRuntimeSnapshot('chats') || {};
        const histories = state.getRuntimeSnapshot('chatHistory') || {};

        if (charId === UNKNOWN_SENDER_ID) {
            // Unknown/spam includes null, empty and undeclared sender IDs.
            // The built-in Communication source is kept in its own system section.
            chatIds = Object.keys(chats).filter(id => {
                const sender = this.src.chat?.[id]?.meta?.sender;
                const isCharacter = sender === 'player' || (typeof sender === 'string' && Object.hasOwn(this.src.characters || {}, sender));
                return sender !== COMMUNICATION_SENDER_ID && !isCharacter;
            });
        } else {
            // Logic chuẩn: Tìm các chat có liên quan đến charId (Sender hoặc Receiver)
            const playerChar = this._getCurrentIdentityKey?.() || this.api.engine.state.get('entryCharacter') || 'player';

            if (this.src.chat) {
                chatIds = Object.keys(this.src.chat).filter(cid => {
                    const meta = this.src.chat[cid].meta;
                    if (!meta) return false;

                    const isSender = meta.sender === charId;
                    const isRecipient = meta.to && Array.isArray(meta.to) && meta.to.includes(charId);

                    // Case 1: CharId gửi cho Player
                    if (isSender && meta.to && meta.to.includes(playerChar)) return true;

                    // Case 2: Player gửi cho CharId (nếu muốn hiển thị history chat mình gửi)
                    if (meta.sender === playerChar && isRecipient) return true;

                    return false;
                });
            }
        }

        const activeThreads = chatIds.filter(id => {
            const hasData = chats[id] && chats[id].set;
            const hasHistory = histories[id] && histories[id].length > 0;
            return (hasData && chats[id].set.activationTime > 0) || hasHistory;
        }).map(id => {
            const c = chats[id];
            const h = histories[id] || [];

            let preview = c.set.desc || "No content";
            if (h.length > 0) {
                const last = h[h.length - 1];
                const entryChar = this._getCurrentIdentityKey?.() || this.api.engine.state.get('entryCharacter') || 'player';
                const senderID = last.nameID || last.char_id;
                preview = `${(senderID === entryChar) ? 'You: ' : ''}${last.text}`;
            }

            // [FIXED] Use API for Title
            const title = this.api.engine.state.get('chat.title', { id: id }) || (charId === UNKNOWN_SENDER_ID ? "Unknown Message" : "No Subject");

            return {
                id: id,
                title: title,
                preview: preview,
                time: c.set.lastInteraction || c.set.activationTime || 0,
                isUnread: c.set.read === false,
                isFinished: c.set.read === true
            };
        });

        activeThreads.sort((a, b) => b.time - a.time);
        return activeThreads;
    },

    startChat(id, triggerActionId = null) {
        const c = this.src.chat[id];
        if (!c) return;

        // A new chat session invalidates any delayed transition owned by the
        // previous chat. The token also guards callbacks that already escaped
        // cancellation or are being delivered by the task manager.
        const transitionToken = this.invalidateChatTransition();

        const ownerId = this.getChatOwner(id);
        const state = this.api.engine.state;
        const chatRuntime = state.getSnapshot('chat.data', { id }) || {};
        if (!chatRuntime.set || typeof chatRuntime.set !== 'object' || Array.isArray(chatRuntime.set)) {
            throw new TypeError(`Chat '${id}' runtime state is missing its set object.`);
        }
        if (!Array.isArray(chatRuntime.set.bookmark)) {
            throw new TypeError(`Chat '${id}' bookmark state must be an array.`);
        }

        if (!chatRuntime.set.activationTime) {
            chatRuntime.set.activationTime = Date.now();
            if (chatRuntime.set.read !== true) chatRuntime.set.read = false;
        }
        chatRuntime.set.lastInteraction = Date.now();

        let chatHistory = state.getSnapshot('chat.history', { id }) || [];
        const isLoop = c.meta && c.meta.loop === true;
        const bookmark = chatRuntime.set.bookmark;

        let startBlock = c.meta.entry;
        if (!startBlock || !Object.hasOwn(c.block || {}, startBlock)) {
            throw new Error(`Chat '${id}' has an invalid or missing meta.entry block.`);
        }
        let startIndex = 0;
        let shouldProcessBlock = true;

        if (isLoop && bookmark.length > 0 && chatRuntime.set.read !== true) {
            chatHistory = [];
            chatRuntime.set.bookmark = [];
            chatRuntime.set.step = 0;
            chatRuntime.set.read = false;

            // Reset scenario-local choice flags as before; these flags are read by resolveBlock.
            if (chatRuntime.block) {
                Object.values(chatRuntime.block).forEach(variants => {
                    Object.values(variants).forEach(v => {
                        if (v.choiced) v.choiced = false;
                    });
                });
            }
        } else if (chatRuntime.set.read === true) {

            // Completed conversations are reconstructed from the scenario bookmark so
            // the selected branch is included. Empty bookmarks retain persisted history.
            if (bookmark.length > 0) {
                chatHistory = [];
                for (const blockId of bookmark) {
                    const blockInfo = this.resolveBlock(id, blockId);
                    if (!blockInfo) continue;

                    if (Array.isArray(blockInfo.line)) {
                        blockInfo.line.forEach(line => {
                            chatHistory.push({ ...line, nameID: line.nameID || line.char_id });
                        });
                    }

                    if (blockInfo.choices && blockInfo.choices.length > 0) {
                        const rawVariant = chatRuntime.block?.[blockId] || c.block[blockId];
                        const pickedChoice = rawVariant?.choiced
                            ? blockInfo.choices.find(ch => ch.set?.choiced === true)
                            : null;
                        if (pickedChoice) {
                            chatHistory.push({
                                nameID: this._getCurrentIdentityKey(),
                                text: pickedChoice.text
                            });
                        }
                    }
                    startBlock = blockId;
                }
            }
            shouldProcessBlock = false;
        } else if (bookmark.length > 0) {
            // Resume after the last persisted line; `step` is the last consumed line index.
            // Keep chat.history intact: it is the authoritative record of already rendered
            // lines and must not be replayed into the same history a second time.
            startBlock = bookmark[bookmark.length - 1];
            const savedStep = Number(chatRuntime.set.step);
            const lastBlock = this.resolveBlock(id, startBlock);
            startIndex = Number.isInteger(savedStep) && savedStep >= 0
                ? Math.min(savedStep + 1, Array.isArray(lastBlock?.line) ? lastBlock.line.length : 0)
                : 0;
        }
        if (chatHistory.length > 0 && bookmark.length === 0) {
            throw new Error(`Chat '${id}' has persisted history without a bookmark.`);
        }

        // Commit the complete progress projection before rendering or dispatching the next block.
        state.set('chat.data', chatRuntime, { id });
        state.set('chat.history', chatHistory, { id });

        const nextChatState = {
            active: true,
            id,
            blockId: startBlock,
            index: startIndex,
            blocking: true,
            waitingChoice: false,
            transitionPending: false,
            transitionToken,
            triggerActionId,
            actionModified: false,
            isProcessing: false,
            ...(!shouldProcessBlock ? { isReview: true } : {})
        };
        state.set('session.chat', nextChatState);

        if (!shouldProcessBlock && this.api.presentation?.chat?.renderChatHistory) {
            this.api.presentation.chat.renderChatHistory(id);
        }

        this.api.presentation.navigation.switchScreen('character');
        this.api.presentation.navigation.selectContact(ownerId);
        this.api.presentation.navigation.openThread(id);
        this.toggleChatOverlay(true);

        // UI navigation is independent from the Engine chat-session lifecycle.
        // In particular, a completed thread becomes inactive immediately after
        // its history is rendered, but React must still open that read-only view.
        this.chatViewRequestSequence = (this.chatViewRequestSequence || 0) + 1;
        this.api.presentation.chat.viewRequested({
            requestId: `chat-view-${Date.now()}-${this.chatViewRequestSequence}`,
            contactId: ownerId,
            chatId: id,
            mode: shouldProcessBlock ? 'active' : 'review',
            headerMode: 'contact'
        });

        if (shouldProcessBlock) {
            this.processChatBlock();
        } else {
            this.api.presentation.chat.renderChatHistory(id);
            hideInput(this);

            // A completed thread is rendered as a read-only view, not kept as an
            // active Engine conversation. The React view remains open independently.
            this.endChatReview();
        }
    },

    _getCurrentIdentityKey() {
        const fakerState = this.api.engine.state.getRuntimeSnapshot('faker') || {};
        return fakerState.active ? fakerState.targetId : (this.api.engine.state.get('entryCharacter') || 'player');
    },

    resolveBlock(chatId, blockId) {
        const chat = this.api.engine.state.getSnapshot('chat.data', { id: chatId }) || this.src.chat[chatId];
        if (!chat || !chat.block) return null;

        let block = chat.block[blockId];
        if (!block) return null;

        // Clone block để xử lý dữ liệu động
        block = JSON.parse(JSON.stringify(block));

        if (block) {
            if (block.choice_id) {
                if (!chat.choice || !Object.hasOwn(chat.choice, block.choice_id)) {
                    throw new Error(`Chat '${chatId}' block '${blockId}' references missing choice group '${block.choice_id}'.`);
                }
                block.choices = chat.choice[block.choice_id];
            } else {
                block.choices = [];
            }

            if (block.line && Array.isArray(block.line)) {
                block.line = block.line.map(lineItem => ({
                    ...lineItem,
                    nameID: lineItem.char_id || lineItem.nameID || (chat.meta && chat.meta.sender ? chat.meta.sender : null)
                }));
            }

            if (block.line) {
                block.type = 'dialogue';
            } else if (block.choices && block.choices.length > 0) {
                block.type = 'router';
            } else {
                block.type = 'dialogue';
            }

            return { id: blockId, ...block };
        }

        return null;
    },

    async processChatBlock() {
        if (!this.chatState.active) return;

        const state = this.api.engine.state;
        state.update('chat.data', current => {
            if (!current?.set) return current;
            current.set.lastInteraction = Date.now();
            if (!Array.isArray(current.set.bookmark)) current.set.bookmark = [];
            const bookmark = current.set.bookmark;
            if (bookmark.length === 0 || bookmark[bookmark.length - 1] !== this.chatState.blockId) {
                bookmark.push(this.chatState.blockId);
            }
            current.set.step = this.chatState.index;
            return current;
        }, { id: this.chatState.id });

        const block = this.resolveBlock(this.chatState.id, this.chatState.blockId);

        if (!block) {
            this.endChat();
            return;
        }

        // Logic check choiced khi BẮT ĐẦU vào block (để chặn loop nếu cấu hình loop=false)
        const chatSrc = this.api.engine.state.getSnapshot('chat.data', { id: this.chatState.id }) || this.src.chat[this.chatState.id];
        const rawBlock = chatSrc.block[block.id];
        const isChoiced = rawBlock && rawBlock.choiced === true;
        const isLoopAllowed = chatSrc.meta && chatSrc.meta.loop === true;

        if (isChoiced && !isLoopAllowed) {
            this.endChat();
            return;
        }

        const handler = ChatBlockHandlers[block.type];
        if (handler) handler(this, block);
        else this.endChat();
    },

    nextChat() {
        if (!this.chatState.active) return;
        // [FIX] If reviewing history, next tap closes the chat.
        if (this.chatState.isReview) {
            this.endChatReview();
            return;
        }
        this.processChatBlock();
    },

    async selectChatChoice(idx) {
        if (!this.chatState?.active || this.chatState.waitingChoice !== true || this.chatState.transitionPending === true) {
            const error = new Error('Chat is not waiting for a choice.');
            error.code = 'CHAT_NOT_WAITING';
            throw error;
        }

        const block = this.resolveBlock(this.chatState.id, this.chatState.blockId);

        if (!block || !block.choices || !block.choices[idx]) return;

        const choice = block.choices[idx];
        if (typeof choice.id !== 'string' || !choice.id) throw new TypeError('Chat choice requires a stable ID.');

        // --- 1. Đánh dấu 'choiced = true' NGAY LẬP TỨC ---
        const chatId = this.chatState.id;
        const blockId = this.chatState.blockId;
        const transitionToken = this.invalidateChatTransition();
        this.api.engine.state.update('session.chat', current => ({
            ...(current || {}), transitionToken
        }));
        this.api.engine.state.update('chat.data', current => {
            const rawBlock = current?.block?.[blockId];
            if (!rawBlock) return current;
            rawBlock.choiced = true;
            const choiceId = rawBlock.choice_id;
            const rawChoice = choiceId && current.choice?.[choiceId]?.[idx];
            if (rawChoice) {
                if (!rawChoice.set) rawChoice.set = {};
                rawChoice.set.choiced = true;
            }
            return current;
        }, { id: chatId });

        // --- 2. Render tin nhắn ---
        const entryChar = this._getCurrentIdentityKey();
        const playerLine = { nameID: entryChar, text: choice.text };

        this.api.engine.state.update('chat.history', history => [...(history || []), playerLine], { id: this.chatState.id });
        this.api.presentation.chat.renderBubble(playerLine, null);

        this.api.presentation.chat.clearChoices();

        this.api.engine.state.update('session.chat', current => ({ ...(current || {}), blocking: true, waitingChoice: false, transitionPending: true }));

        // --- 3. Run Effect ---
        if (choice.effect) {
            const choiceId = choice.id;
            try {
                await this.processRunnables(choice.effect, {
                    sceneId: this.api.engine.state.get('sceneId'),
                    chatId,
                    blockId,
                    choiceId
                });
            } catch (error) {
                const session = this.api.engine.state.getSession('chatState');
                if (session?.active && session.id === chatId && session.blockId === blockId && session.transitionToken === transitionToken) {
                    this.api.engine.state.update('session.chat', current => ({
                        ...(current || {}), transitionPending: false, waitingChoice: true
                    }));
                }
                throw error;
            }
            const currentSession = this.api.engine.state.getSession('chatState');
            if (!currentSession?.active || currentSession.id !== chatId || currentSession.blockId !== blockId || currentSession.transitionToken !== transitionToken || this._chatTransitionToken !== transitionToken) return;
        }

        // --- 4. Logic JUMP + Kiểm tra CHOICED của Đích ---
        let nextBlockId = choice.jump;
        const chatData = this.api.engine.state.getSnapshot('chat.data', { id: this.chatState.id }) || this.src.chat[this.chatState.id];

        // Nếu jump hợp lệ, kiểm tra xem block đích có tồn tại không
        if (nextBlockId) {
            if (!chatData || !chatData.block || !Object.hasOwn(chatData.block, nextBlockId)) {
                throw new Error(`Chat '${this.chatState.id}' choice jump references missing block '${nextBlockId}'.`);
            } else {
                const targetBlockInfo = this.resolveBlock(this.chatState.id, nextBlockId);
                if (targetBlockInfo) {
                    const rawTarget = chatData.block[nextBlockId];

                    if (rawTarget && rawTarget.choiced === true) {
                        nextBlockId = null; // FORCE END
                    }
                }
            }
        }

        if (nextBlockId) {
            this.scheduleDelay(500, () => {
                const currentSession = this.api.engine.state.getSession('chatState');
                if (!currentSession?.active || currentSession.id !== chatId ||
                    currentSession.blockId !== blockId || currentSession.transitionPending !== true ||
                    currentSession.transitionToken !== transitionToken ||
                    this._chatTransitionToken !== transitionToken) return;

                this.api.engine.state.update('session.chat', current => ({
                    ...current,
                    blockId: nextBlockId,
                    index: 0,
                    transitionPending: false
                }));
                this.api.engine.state.update('chat.data', current => {
                    if (current?.set) current.set.step = 0;
                    return current;
                }, { id: chatId });

                this.processChatBlock();
                this.toggleChatOverlay(true);
                this.api.presentation.refresh();
                this.api.presentation.components.inputBar();
                this.commitState('chat.block.transition');

            }, 'chat_transition');
        } else {
            // End Chat
            this.scheduleDelay(500, () => {
                const currentSession = this.api.engine.state.getSession('chatState');
                if (!currentSession?.active || currentSession.id !== chatId ||
                    currentSession.blockId !== blockId || currentSession.transitionPending !== true ||
                    currentSession.transitionToken !== transitionToken ||
                    this._chatTransitionToken !== transitionToken) return;
                this.endChat();
            }, 'chat_transition');
        }
    },

    // End only the transient review session. Do not mark the thread read again,
    // hide gameplay actions, or emit Presentation commands: the client owns the
    // already-rendered read-only history view.
    endChatReview() {
        const state = this.api.engine.state;
        state.set('session.chat', {
            ...(this.chatState || {}),
            active: false,
            blocking: false,
            waitingChoice: false,
            transitionPending: false,
            isReview: false
        });
    },

    // Completing a live conversation also performs the gameplay and Presentation
    // side effects. Keep this separate from ending a read-only review session.
    endChat() {
        this.invalidateChatTransition();
        const chatId = this.chatState.id;

        const state = this.api.engine.state;
        if (chatId) {
            state.update('chat.data', current => {
                if (current?.set) current.set.read = true;
                return current;
            }, { id: chatId });
            state.update('actions', current => {
                const actions = current || {};
                for (const actionState of Object.values(actions)) {
                    if (actionState.type === 'show_chat' && actionState.target === chatId) {
                        actionState.display = 'hide';
                    }
                }
                return actions;
            });
        }
        state.update('session.chat', current => ({
            ...(current || {}),
            active: false,
            blocking: false,
            waitingChoice: false,
            transitionPending: false,
            isReview: false
        }));

        this.toggleChatOverlay(false);
        hideInput(this);
        this.api.presentation.chat.renderContactList();
        this.api.presentation.refresh();
    }
};