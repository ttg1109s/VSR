import { importModules } from './imports/index.js';
const __testModules = await importModules(["WorkerJsonTransport"]);
const { WorkerJsonTransport } = __testModules.WorkerJsonTransport;

import test from 'node:test';
import assert from 'node:assert/strict';

class FakeWorker {
  constructor({ respond = true, failPost = false } = {}) { this.listeners = new Map(); this.messages = []; this.terminated = false; this.respond = respond; this.failPost = failPost; }
  addEventListener(type, listener) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(listener);
  }
  removeEventListener(type, listener) { this.listeners.get(type)?.delete(listener); }
  postMessage(message) {
    if (this.failPost && message.type === 'request') throw new Error('postMessage failed');
    this.messages.push(message);
    if (this.respond && message.type === 'request') {
      queueMicrotask(() => this.emit('message', {
        data: { type: 'response', requestId: message.requestId, ok: true, body: JSON.stringify({
          protocol: 'vsr', protocolVersion: 2, type: 'ack',
          commandId: message.command.commandId, ok: true
        }) }
      }));
    }
  }
  emit(type, event) { for (const listener of this.listeners.get(type) || []) listener(event); }
  terminate() { this.terminated = true; }
}

test('WorkerJsonTransport sends JSON commands and resolves JSON acknowledgements', async () => {
  const worker = new FakeWorker();
  const transport = new WorkerJsonTransport({ worker });
  const command = { protocol: 'vsr', protocolVersion: 2, type: 'command', commandId: 'test-1', command: 'engine.pause', payload: {} };
  const ack = JSON.parse(await transport.request(JSON.stringify(command)));
  assert.equal(ack.ok, true);
  assert.deepEqual(worker.messages[0].command, command);
  transport.close();
  assert.equal(worker.terminated, true);
});

test('WorkerJsonTransport forwards protocol events to JSON subscribers', () => {
  const worker = new FakeWorker();
  const transport = new WorkerJsonTransport({ worker });
  const received = [];
  transport.subscribe(message => received.push(JSON.parse(message)));
  const event = { protocol: 'vsr', protocolVersion: 2, type: 'event', event: 'engine.ready', payload: {} };
  worker.emit('message', { data: { type: 'event', message: event } });
  assert.deepEqual(received, [event]);
  transport.close();
});

test('WorkerJsonTransport rejects pending requests when closed', async () => {
  const worker = new FakeWorker();
  const transport = new WorkerJsonTransport({ worker });
  const request = transport.request({ protocol: 'vsr', protocolVersion: 2, type: 'command', commandId: 'test-2', command: 'engine.pause', payload: {} });
  transport.close();
  await assert.rejects(request, /closed/i);
});

test('WorkerJsonTransport rejects requests when the worker does not respond before timeout', async () => {
  const worker = new FakeWorker({ respond: false });
  const transport = new WorkerJsonTransport({ worker, requestTimeoutMs: 5 });
  const request = transport.request({ protocol: 'vsr', protocolVersion: 2, type: 'command', commandId: 'timeout', command: 'engine.pause', payload: {} });
  await assert.rejects(request, error => {
    assert.match(error.message, /timed out after 5 ms/i);
    assert.equal(error.code, 'TRANSPORT_TIMEOUT');
    assert.equal(error.outcome, 'unknown');
    return true;
  });
  assert.equal(transport.pending.size, 0);
  transport.close();
});

test('WorkerJsonTransport rejects pending requests when the worker errors', async () => {
  const worker = new FakeWorker({ respond: false });
  const transport = new WorkerJsonTransport({ worker, requestTimeoutMs: 1000 });
  const request = transport.request({ protocol: 'vsr', protocolVersion: 2, type: 'command', commandId: 'worker-error', command: 'engine.pause', payload: {} });
  worker.emit('error', { error: new Error('worker crashed') });
  await assert.rejects(request, error => {
    assert.match(error.message, /worker crashed/);
    assert.equal(error.code, 'WORKER_FAILED');
    assert.equal(error.outcome, 'unknown');
    return true;
  });
  assert.equal(transport.pending.size, 0);
  transport.close();
});

test('WorkerJsonTransport clears a request timeout when postMessage throws', async () => {
  const worker = new FakeWorker({ respond: false, failPost: true });
  const transport = new WorkerJsonTransport({ worker, requestTimeoutMs: 5 });
  await assert.rejects(transport.request({ protocol: 'vsr', protocolVersion: 2, type: 'command', commandId: 'post-error', command: 'engine.pause', payload: {} }), /postMessage failed/);
  assert.equal(transport.pending.size, 0);
  transport.close();
});

test('WorkerJsonTransport emits exactly one generic acknowledgment message type', () => {
  const worker = new FakeWorker();
  const transport = new WorkerJsonTransport({ worker });
  assert.equal(transport.acknowledge('pres-test', { status: 'committed' }), true);
  assert.deepEqual(worker.messages.at(-1), { type: 'acknowledgment', requestId: 'pres-test', response: { status: 'committed' } });
  assert.equal(transport.acknowledge('', {}), false);
  transport.close();
  assert.equal(transport.acknowledge('after-close', {}), false);
});
